﻿namespace MyLib
{
    public interface IShape
    {
        string MagicWord { get; }
    }
}

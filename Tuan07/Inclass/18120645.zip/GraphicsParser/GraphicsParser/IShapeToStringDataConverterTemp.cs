using GraphicsParser;
using System;

namespace GraphicsParser
{
    public interface IShapeToStringDataConverterTemp : IShapeTemp
    {

    }
}
